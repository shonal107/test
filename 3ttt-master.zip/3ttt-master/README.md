# 3dttt

3D Tic Tac Toe with AI using Minimax and Alpha-Beta pruning. Includes a very basic text based version and a Tkinter based UI. Try running `$ python ttt.py` or `$ python ui.py` to play with the Tkinter UI.

![Sample Play](sample.png)
